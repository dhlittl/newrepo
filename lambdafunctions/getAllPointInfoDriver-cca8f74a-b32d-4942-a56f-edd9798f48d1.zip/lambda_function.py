import json
import mysql.connector
from decimal import Decimal
from datetime import datetime

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        elif isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)

def lambda_handler(event, context):
    print("Event received:", json.dumps(event))
    try:
        # Connect to the RDS Database
        cnx = mysql.connector.connect(
            host='proxy-1741015331966-cpsc4911-team24.proxy-cobd8enwsupz.us-east-1.rds.amazonaws.com',
            user='admin',
            password='4911Admin2025',
            database='team24database'
        )
        cursor = cnx.cursor(dictionary=True)
        
        # Retrieve userId from query string parameters
        query_params = event.get('queryStringParameters') or {}
        print("Query parameters:", query_params)
        user_id = query_params.get('userId')
        sponsor_id = query_params.get('sponsorId')
        
        if user_id is None:
            return {
                'statusCode': 400,
                'headers': {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Headers": "Content-Type",
                    "Access-Control-Allow-Methods": "OPTIONS,GET"
                },
                'body': json.dumps({'error': 'Missing userId parameter'})
            }
        
        # Get driver ID from user ID
        driver_query = "SELECT Driver_ID FROM Driver WHERE User_ID = %s"
        cursor.execute(driver_query, (user_id,))
        driver_result = cursor.fetchone()
        
        if not driver_result:
            return {
                'statusCode': 404,
                'headers': {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Headers": "Content-Type",
                    "Access-Control-Allow-Methods": "OPTIONS,GET"
                },
                'body': json.dumps({'error': 'Driver not found for this user'})
            }
            
        driver_id = driver_result['Driver_ID']
        
        # Query to get point history
        point_history_query = """
        SELECT pc.*, so.Sponsor_Org_Name
        FROM Point_Changes pc
        JOIN Sponsor_Organization so ON pc.Sponsor_Org_ID = so.Sponsor_Org_ID
        WHERE pc.Driver_ID = %s
        """
        
        params = [driver_id]
        
        # Add sponsor filter if provided
        if sponsor_id:
            point_history_query += " AND pc.Sponsor_Org_ID = %s"
            params.append(sponsor_id)
            
        point_history_query += " ORDER BY pc.Change_Date DESC"
        
        cursor.execute(point_history_query, params)
        point_history = cursor.fetchall()
        
        # Query to get current balances
        balances_query = """
        SELECT d2s.Sponsor_Org_ID, so.Sponsor_Org_Name, d2s.Point_Balance
        FROM Driver_To_SponsorOrg d2s
        JOIN Sponsor_Organization so ON d2s.Sponsor_Org_ID = so.Sponsor_Org_ID
        WHERE d2s.Driver_ID = %s
        """
        
        cursor.execute(balances_query, (driver_id,))
        balances = cursor.fetchall()
        
        cursor.close()
        cnx.close()
        
        # Return formatted response
        return {
            'statusCode': 200,
            'headers': {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "OPTIONS,GET"
            },
            'body': json.dumps({
                'point_history': point_history,
                'current_balances': balances
            }, cls=DecimalEncoder)
        }
        
    except Exception as e:
        print("Error:", str(e))
        return {
            'statusCode': 500,
            'headers': {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "OPTIONS,GET"
            },
            'body': json.dumps({'error': str(e)})
        }